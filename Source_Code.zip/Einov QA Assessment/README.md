# Simple inventory management system in C# .NET 8.0
Technical skills assessment for QA specialist

[![.NET](https://github.com/formidablefrank/inventory_mgmt/actions/workflows/dotnet.yml/badge.svg?branch=main)](https://github.com/formidablefrank/inventory_mgmt/actions/workflows/dotnet.yml)
